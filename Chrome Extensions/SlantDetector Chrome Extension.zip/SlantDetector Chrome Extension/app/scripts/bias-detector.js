console.log('bias-detector.js -- starting');

(function() {

  chrome.tabs.query({'active': true, 'currentWindow': true}, function (tabs) { // getting the current tab attr
    var url = tabs[0].url;

    //chrome.storage.sync.set({'url': url}, function(){

      var striptags = require('striptags');
      var fs = require('fs');
      var read = require('node-read');

      read(url, function(err, article, meta) {
        var article = striptags(article.content); //fs.readFileSync(`${__dirname}/../data/test.txt`, 'utf8').toString()
        console.log(article);

        var BayesClassifier = require('bayes-classifier');

        var trainedModel = require("../data/NB-model.json");
        var classifier = new BayesClassifier();
        classifier.restore(trainedModel); // restore from trained model

        var result = classifier.classify(article);
        var predictions = classifier.getClassifications(article);


        if( predictions[0].value == predictions[1].value){ // dealing with neutrality
          result = 'Neutral'
        }
        console.log(result)
        console.log();
        console.log(predictions[1].value);
        var total = parseInt(predictions[0].value) + parseInt(predictions[1].value)
        var cons = (parseInt(predictions[0].value) / total ) * 100
        var lib = (parseInt(predictions[1].value) / total ) * 100

        chrome.storage.sync.set({'label': result});
        chrome.storage.sync.set({'consAccuracy': cons }); // conservative accuracy
        chrome.storage.sync.set({'libAccuracy': lib }); // liberal accuracy


      });


    //});

  });



})();


console.log('bias-detector.js -- End');