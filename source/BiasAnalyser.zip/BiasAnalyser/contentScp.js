function getText(){
    return document.body.innerText
}

console.log("This is fact extension V2.01");
console.log(getText());             //Gives you all the text on the page
