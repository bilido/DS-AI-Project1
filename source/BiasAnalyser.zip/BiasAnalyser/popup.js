$(function(){

    

    $('#analyseContent').click(function(){
        
            $('#results').text('Processing the results');
            var winner1 = go(getText());
            var winner2 = go(getText());

            $('#results').text('The results are:');
            $('#conservativeResult').text(winner1);
            $('#liberalResult').text(winner2);
            

           

        
    });
});


